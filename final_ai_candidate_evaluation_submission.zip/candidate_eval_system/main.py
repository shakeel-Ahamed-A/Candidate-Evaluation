from candidate_eval.cli import main
if __name__ == "__main__":
    main()
