---
name: Bug report
about: Report a reproducible problem
---

## Description

Describe the problem clearly.

## Reproduction

```text
Commands, input files, and steps
```

## Expected behavior

## Actual behavior

## Environment

- Python version:
- OS:
- Provider: mock/openai
