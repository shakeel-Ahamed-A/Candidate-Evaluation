---
name: Feature request
about: Suggest an improvement
---

## Problem

What problem would this feature solve?

## Proposed solution

Describe the behavior you would like.

## Evaluation-integrity impact

Explain whether the proposal changes evidence grounding, agent isolation, debate behavior, or decision logic.
