## Summary

Describe the change and why it is needed.

## Validation

- [ ] `pytest -q`
- [ ] `python -m compileall -q candidate_eval main.py`
- [ ] `python main.py --mock`

## Integrity checklist

- [ ] Agent isolation remains intact before debate
- [ ] Findings retain source evidence
- [ ] Debate changes are explicitly recorded
- [ ] Decision logic does not reduce to score averaging
